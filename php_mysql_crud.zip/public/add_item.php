<?php
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item = $_POST['item'];
    $sql = "INSERT INTO items (nombre) VALUES ('$item')";
    $conn->query($sql);
    header("Location: index.php");
}
?>