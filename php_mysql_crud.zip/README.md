# Proyecto CRUD en PHP y MySQL

Este es un proyecto básico de CRUD (Create, Read, Update, Delete) en PHP con MySQL.

## Instalación

1. Importa el archivo `sql/database.sql` en MySQL.
2. Configura los datos de conexión en `config/database.php`.
3. Ejecuta el servidor local y abre `public/index.php`.
    